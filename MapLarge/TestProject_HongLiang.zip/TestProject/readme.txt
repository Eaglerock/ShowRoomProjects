Notes for running/testing below functions:

*browse folder: file name and path can be set in "web.config" with parameter "MyFilesPath"; or to be passed from url
  example: http://localhost:55749/Home/BrowseFolder/view, "view" is the folder name (paramter) that will be browsed inside 
           current project folder.

*upload: file is to be uploaded to "~/Documents/" folder in the project folder.

*download: assuming only image/jpeg type file will be downloaded. The source image file is from "~/App_Data/Images" 