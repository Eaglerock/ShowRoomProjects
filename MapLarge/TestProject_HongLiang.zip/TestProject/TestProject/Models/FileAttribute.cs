﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace TestProject.Models
{
    public class FileAttribute
    {
        [Required(ErrorMessage = "{0} is required")]
        [Display(Name = "File Description")]
        public string DownloadFileName{ get; set; }

        public FileAttribute()
        {
            DownloadFileName = "no download file name";
        }
    }
}