﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestProject.Models
{
    enum ContentType
    {
        Folder = 1,
        File = 2
    }

    public class DirectoriesFiles
    {
        public string DirectoryPath { get; set; }
        public List<Content> ContentArr { get; set; }
        public int FolderCounts { get; set; }
        public int FileCounts { get; set; }

        public DirectoriesFiles()
        {
            ContentArr = new List<Content>();
        }
        public void SetContentCounts()
        {
            FolderCounts = ContentArr.Count(c => c.ItemAttribute == ContentType.Folder.ToString());
            FileCounts = ContentArr.Count(c => c.ItemAttribute == ContentType.File.ToString());
        }
    }

    public class Content
    {
        public string ItemAttribute { get; set; }
        public string Name { get; set; }
        public long ItemSize { get; set; }
    }
}