﻿/*
By: Hong Liang (Hong.Liang.3@gmail.com) for MapLarge
Date: 8/23/2016
*/

using System;
using System.IO;
using System.Web;
using System.Linq;
using System.Web.Mvc;
using TestProject.Models;
using System.Configuration;
using System.Collections.Generic;

namespace TestProject.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        #region Actions

        [HttpGet]
        public ActionResult UploadFile()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadFile(FileAttribute model)
        {
            bool isUploaded = false;
            string message = "";
            foreach (string upload in Request.Files)
            {
                if (Request.Files[upload].ContentLength == 0) continue;
                string pathToSave = Server.MapPath("~/Documents/");
                string filename = Path.GetFileName(Request.Files[upload].FileName);
                if (this.CreateFolderIfNeeded(pathToSave))
                {
                    try
                    {
                        Request.Files[upload].SaveAs(Path.Combine(pathToSave, filename));
                        isUploaded = true;
                        message = message + " File " + filename + " uploaded successfully!";
                    }
                    catch (Exception ex)
                    {
                        message = message + string.Format(" File " + filename + " upload failed: {0}", ex.Message);
                    }
                }

            }
            return Json(new { isUploaded = isUploaded, message = message }, "text/html");
        }

        // GET: Home/Download
        public FileResult Download(string ImageName)
        {
            //this line is to show image
            //return File("~/App_Data/Images/" + ImageName, System.Net.Mime.MediaTypeNames.Image.Jpeg);

            var path = Server.MapPath(@"~/App_Data/Images/" + ImageName);
            var contents = System.IO.File.ReadAllBytes(path);

            var header = new System.Net.Mime.ContentDisposition()
            {
                FileName = ImageName,
                Inline = false
            };

            Response.AddHeader("Content-Disposition", header.ToString());

            return File(contents, "image/jpeg");
        }

        /// <summary>
        /// Browing the content inside a folder. 
        /// Notes: folder name can be from url or configurated in web.config. 
        /// If the folder name is from url ("view" in http://localhost:55749/Home/BrowseFolder/view), 
        /// the parent folder is current working folder, otherwise, the folder name and its path 
        /// is from web.config parameter "MyFilesPath".
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: Home/BrowseFolder
        public ActionResult BrowseFolder(string id)
        {
            string dirPath = id == null ? ConfigurationManager.AppSettings["MyFilesPath"] : Server.MapPath(@"~\" + id);
            List<FileInfo> files = new List<FileInfo>();
            List<DirectoryInfo> folders = new List<DirectoryInfo>();
            DirectoryInfo directory = new DirectoryInfo(dirPath);
            try
            {
                files = directory.GetFiles().ToList();
                folders = directory.GetDirectories().ToList();
            }
            catch (Exception exp) {; }
            // populate DirectoriesFiles
            DirectoriesFiles df = new DirectoriesFiles();
            df.ContentArr = (from fl in files
                             select new Content
                             {
                                 ItemAttribute = ContentType.File.ToString(),
                                 Name = fl.Name,
                                 ItemSize = fl.Length
                             }).ToList();
            var fdList = (from fd in folders
                          select new Content
                          {
                              ItemAttribute = ContentType.Folder.ToString(),
                              Name = fd.Name
                          }).ToList();
            df.ContentArr.AddRange(fdList);
            df.SetContentCounts();
            df.DirectoryPath = dirPath;
            return Json(df, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Creates the folder if needed.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns></returns>
        private bool CreateFolderIfNeeded(string path)
        {
            bool result = true;
            if (!Directory.Exists(path))
            {
                try
                {
                    Directory.CreateDirectory(path);
                }
                catch (Exception)
                {
                    /*TODO: You must process this exception.*/
                    result = false;
                }
            }
            return result;
        }

        #endregion    
    }
}